const  prisma = require("../db/index.js")

const findSiswaKelas = async () => {
    const siswaKelas = await prisma.siswa_Kelas.findMany({
        where: { 
            is_active: true
        }
    })

    return siswaKelas
}

const findSiswaKelasById = async (id) => {
    const siswaKelas = await prisma.siswa_Kelas.findUnique({
        where:{
            id:id, 
        }
    }) 

    
    return siswaKelas
}

const insertSiswaKelas = async (newSiswaKelasData) => { 
    const siswaKelas = await prisma.siswa_Kelas.create({
        data:{  
            siswa_id: newSiswaKelasData.siswa_id , 
            kelas_id: newSiswaKelasData.kelas_id ,  
            is_active      :newSiswaKelasData.is_active,
            is_delete     :newSiswaKelasData.is_delete ,
        }
    })
    return siswaKelas
}

const deleteSiswaKelas = async (id) => {
    await prisma.siswa_Kelas.delete({
        where: {
            id: id
        }
    }) 
}

const editSiswaKelas = async (id, siswaKelasData) => { 
    const siswaKelas =  await  prisma.siswa_Kelas.update({
        where:{
            id: id
        },
        data:{  
            siswa_id: siswaKelasData.siswa_id , 
            kelas_id: siswaKelasData.kelas_id ,  
            is_active      :siswaKelasData.is_active,
            is_delete     :siswaKelasData.is_delete ,
        }
    })

    return siswaKelas
}
 

module.exports = {
    findSiswaKelas,
    findSiswaKelasById,
    insertSiswaKelas,
    deleteSiswaKelas,
    editSiswaKelas
}